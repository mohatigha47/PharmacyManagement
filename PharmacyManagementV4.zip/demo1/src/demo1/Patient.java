/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo1;

import java.io.Serializable;

/**
 *
 * @author MoHaTiGha
 */
public class Patient implements Serializable{
    int ID;
    String FirstName;
    String LastName;
    int Age;
    String Gender;
    String PhoneNumber;
    String Adress;
    String Note;
    public Patient(int ID,String FirstName,String LastName,String Gender,int Age,String PhoneNumber,String Adress,String Note){
        this.ID = ID;
        this.FirstName = FirstName;
        this.Gender = Gender;
        this.PhoneNumber = PhoneNumber;
        this.LastName = LastName;
        this.Age = Age;
        this.Adress = Adress;
        this.Note = Note;
    }
}
