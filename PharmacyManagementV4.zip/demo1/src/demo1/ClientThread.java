/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo1;

/**
 *
 * @author MoHaTiGha
 */
public class ClientThread {
    Thread thread;
    String clientName;

    public ClientThread(Thread thread, String clientName) {
        this.thread = thread;
        this.clientName = clientName;
    }

    
}
