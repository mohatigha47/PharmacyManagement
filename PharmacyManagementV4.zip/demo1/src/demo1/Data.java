package demo1;

import java.io.Serializable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author MoHaTiGha
 */
public class Data implements Serializable{
    String instruction;
    Object object;
    public Data(String instruction,Object object){
        this.instruction = instruction;
        this.object = object; 
    }
}
