/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo1;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Demo1 {

    static ArrayList<Order> orders = new ArrayList();

    public static void main(String[] args) {
        try {
            DateTimeFormatter formatterDateAndHour = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime myDate = LocalDateTime.now();
            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            java.util.Date date = formatter.parse("12/12/2001");
            Timestamp ts = new Timestamp(date.getTime());
            System.out.println(ts);

                
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void AddLog(String code, String client, String purchase_ID, String total_price, Timestamp date) {
        String query = "INSERT INTO log VALUES ('" + code + "','" + client + "'," + purchase_ID + "," + total_price + ", TIMESTAMP '" + date + "')";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPatient(String code , String name , String last_name,String gender,String Age , String phone_number , String adresse , String note) {
		String query = "INSERT INTO patients VALUES ('"+code+"','"+name+"','"+last_name+"',"+phone_number+","+adresse+",'"+note+"','"+Age+"',"+gender+")";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");     
	           String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPurchase(String code, String product, String quantity) {
        String query = "INSERT INTO purchases VALUES ('" + code + "','" + product + "'," + quantity + ")";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    

    public static void initializeOrders() {
        String query = "SELECT * FROM log";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            Statement st1 = connection.createStatement();
            Statement st2 = connection.createStatement();
            Statement st3 = connection.createStatement();
            Statement st4 = connection.createStatement();
            ResultSet rs = st1.executeQuery(query);
            while (rs.next()) {
                ResultSet prs = st2.executeQuery("SELECT * FROM patients WHERE code = " + rs.getInt("client") + ";");
                prs.next();
                Patient p = new Patient(Integer.parseInt(prs.getString("code")), prs.getString("first_name"), prs.getString("last_name"),prs.getString("gender"), prs.getInt("age"), prs.getString("adresse"), prs.getString("note"), prs.getString("phone_number"));
                prs.close();
                ResultSet mrs = st3.executeQuery("SELECT * FROM purchases WHERE code = " + rs.getInt("purchase_ID") + ";");
                ArrayList<ProductOnCart> cartArray = new ArrayList<ProductOnCart>();
                while (mrs.next()) {
                    ResultSet srs = st4.executeQuery("SELECT * FROM medications WHERE code = " + mrs.getInt("product") + ";");
                    srs.next();
                    Product m = new Product(srs.getInt("code"), srs.getString("name"), srs.getString("category"), "someone", srs.getInt("sell_price"), srs.getInt("buy_price"), srs.getInt("quantity"), srs.getString("exp_date"));
                    srs.close();
                    ProductOnCart poc = new ProductOnCart(m, mrs.getInt("quantity"));
                    cartArray.add(poc);

                }
                orders.add(new Order(rs.getInt("code"), p, cartArray, LocalDateTime.now()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddMedication(String code, String name, String sell_price, String buy_price, String quantity, String exp_date, String category) {
        String query = "INSERT INTO medications VALUES ('" + code + "','" + name + "'," + sell_price + "," + buy_price + "," + quantity + ", '" + exp_date + "','" + category + "')";
        try {
            System.out.println(query);
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void Remove(String table, String PrimaryKey) {
        String query = "DELETE FROM " + table + " WHERE code= '" + PrimaryKey + "'";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//	public static void AddLog(String code , String product ,String client ,String quantity ,String total_price, String date ) {
//		String query = "INSERT INTO log VALUES ('"+code+"','"+product+"','"+client+"',"+quantity+","+total_price+", DATE '"+date+"')";
//		try {
//		Class.forName("com.mysql.cj.jdbc.Driver");     
//	    String url = "jdbc:mysql://localhost:3306/phar_database";
//	    Connection connection = DriverManager.getConnection(url,"root","Mohmed.4717");
//	    PreparedStatement pst = connection.prepareStatement(query);
//                    System.out.println("DONE");
//	    pst.execute(query);
//		}catch(Exception e) {
//		e.printStackTrace();
//		}
//	}

}
