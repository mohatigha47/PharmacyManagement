/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo1;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author moh
 */
public class Product implements Serializable{
    int ID;
    String Name;
    String Category;
    String Supplier;
    int Quantity;
    double BuyPrice;
    double SellPrice;
    String ExpDate;
    public Product(int ID,String Name,String Category,String Supplier,int Quantity,double BuyPrice,double SellPrice,String ExpDate){
        this.ID = ID;
        this.Name = Name;
        this.Category = Category;
        this.Supplier = Supplier;
        this.Quantity = Quantity;
        this.BuyPrice = BuyPrice;
        this.SellPrice = SellPrice;
        this.ExpDate = ExpDate;
    }
}
