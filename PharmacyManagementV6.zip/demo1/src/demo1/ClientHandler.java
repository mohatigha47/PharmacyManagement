package demo1;


import java.net.*;
import java.io.*;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author moh
 */
public class ClientHandler implements Runnable{
    String Name;
    Socket socket;
    boolean Stop;
    //InputStreamReader inputStreamReader;
    //OutputStreamWriter outputStreamWriter;
    ObjectOutputStream objectOutputStream;
    ObjectInputStream objectInputStream;
    public ClientHandler(String Name,Socket socket,ObjectInputStream objectInputStream,ObjectOutputStream objectOutputStream){
        this.Name = Name;
        this.socket = socket;
        Stop = false;
        //this.inputStreamReader = inputStreamReader;
        //this.outputStreamWriter = outputStreamWriter;  
        this.objectInputStream = objectInputStream;
        this.objectOutputStream = objectOutputStream;
    }

    @Override
    public void run() {
        
        
    }
        
}
