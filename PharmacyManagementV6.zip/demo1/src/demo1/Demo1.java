/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo1;

import static demo1.server.OrdersList;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Demo1 {

    static ArrayList<Order> orders = new ArrayList();

    public static void main(String[] args) {
        try {
            String str1 = "2016-03-04 11:30:00";
            String str2 = "2025-03-05 11:30:00";
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime dateTime1 = LocalDateTime.parse(str1, formatter);
            LocalDateTime dateTime2 = LocalDateTime.parse(str2, formatter);
            Duration duration = Duration.between(dateTime1, dateTime2);
            System.out.println(duration.toDays());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void UpdatePatient2(Patient p) {
        String query = "UPDATE patients SET "
                + "code = " + "'" + p.ID + "',first_name = '" + p.FirstName + "',last_name = '" + p.LastName + "',age ="
                + " " + p.Age + ",phone_number = " + p.PhoneNumber + ",adresse = '" + p.Adress + "',note = '" + p.Note + "' "
                + "WHERE code = " + p.ID + "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void initializeOrders() {
        ArrayList<Order> tempOrders = new ArrayList();
        String query = "SELECT * FROM log";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            Statement st1 = connection.createStatement();
            Statement st2 = connection.createStatement();
            Statement st3 = connection.createStatement();
            Statement st4 = connection.createStatement();
            ResultSet rs = st1.executeQuery(query);
            while (rs.next()) {
                ResultSet prs = st2.executeQuery("SELECT * FROM patients WHERE code = " + rs.getInt("client") + ";");
                prs.next();
                Patient p = new Patient(prs.getInt("code"), prs.getString("first_name"), prs.getString("last_name"), prs.getString("phone_number"), prs.getString("adresse"), prs.getString("note"), Integer.parseInt(prs.getString("age").trim()), prs.getString("gender"));
                prs.close();
                ResultSet mrs = st3.executeQuery("SELECT * FROM purchases WHERE code = " + rs.getInt("purchase_ID") + ";");
                ArrayList<ProductOnCart> cartArray = new ArrayList<ProductOnCart>();
                while (mrs.next()) {
                    ResultSet srs = st4.executeQuery("SELECT * FROM medications WHERE code = " + mrs.getInt("product") + ";");
                    srs.next();
                    Product m = new Product(srs.getInt("code"), srs.getString("name"), srs.getString("category"), "someone", srs.getInt("sell_price"), srs.getInt("buy_price"), srs.getInt("quantity"), srs.getString("exp_date"));
                    srs.close();
                    ProductOnCart poc = new ProductOnCart(m, mrs.getInt("quantity"));
                    cartArray.add(poc);
                }
                tempOrders.add(new Order(rs.getInt("code"), p, cartArray, LocalDateTime.now()));
            }
            orders = tempOrders;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void UpdatePatient(Patient p) {
        String query = "UPDATE patients SET "
                + "code = " + "'" + p.ID + "',first_name = '" + p.FirstName + "',last_name = '" + p.LastName + "',age ="
                + " " + p.Age + ",phone_number = " + p.PhoneNumber + ",adresse = '" + p.Adress + "',note = '" + p.Note + "' "
                + "WHERE code = " + p.ID + "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPatient2(String ID, String FirstName, String LastName, String PhoneNumber, String Adress, String Note, String Age, String Gender) {
        String query = "INSERT INTO patients VALUES ('" + ID + "','" + FirstName + "','" + LastName + "','" + PhoneNumber + "','" + Adress + "','" + Note + "','" + Age + "','" + Gender + "' )";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPatient(String code, String name, String last_name, String gender, String Age, String phone_number, String adresse, String note) {
        String query = "INSERT INTO Patients VALUES ('" + code + "','" + name + "','" + last_name + "'," + phone_number + "," + adresse + ",'" + note + "','" + Age + "'," + gender + ")";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddLog(String code, String client, String purchase_ID, String total_price, Timestamp date) {
        String query = "INSERT INTO log VALUES ('" + code + "','" + client + "'," + purchase_ID + "," + total_price + ", TIMESTAMP '" + date + "')";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPurchase(String code, String product, String quantity) {
        String query = "INSERT INTO purchases VALUES ('" + code + "','" + product + "'," + quantity + ")";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddMedication(String code, String name, String sell_price, String buy_price, String quantity, String exp_date, String category) {
        String query = "INSERT INTO medications VALUES ('" + code + "','" + name + "'," + sell_price + "," + buy_price + "," + quantity + ", '" + exp_date + "','" + category + "')";
        try {
            System.out.println(query);
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void Remove(String table, String PrimaryKey) {
        String query = "DELETE FROM " + table + " WHERE code= '" + PrimaryKey + "'";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
