package demo1;

import static demo1.Demo1.orders;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.midi.Receiver;

public class server {

    static int i = 0;
    static ArrayList<ClientHandler> Clients = new ArrayList();
    //static ArrayList<ClientThread> ClientsThread = new ArrayList();
    static ArrayList<Product> ProductsStock = new ArrayList();
    static ArrayList<Order> OrdersList = new ArrayList();
    static ArrayList<Patient> PatientsList = new ArrayList();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(4999);
        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("Connected");
            i++;
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            ClientHandler client = new ClientHandler("Client " + i, socket, objectInputStream, objectOutputStream);
            objectOutputStream.writeObject(new Data("CLIENT NAME", client.Name));
            Clients.add(client);
            Thread clientThread = new Thread(client);
            //ClientsThread.add(new ClientThread(clientThread,client.Name));
            clientThread.start();
            Thread receiveMsg = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        try {
                            Data DataReceived = (Data) objectInputStream.readObject();
                            String Instruction = DataReceived.instruction;
                            if (Instruction.equals("FETCH PRODUCTS")) {
                                initialize();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("PRODUCTS GIVEN", ProductsStock));
                                }
                            } else if (Instruction.equals("ADD PRODUCT")) {
                                Product productToAdd = (Product) DataReceived.object;
                                Timestamp expDate = Timestamp.valueOf(productToAdd.ExpDate);
                                AddMedication(String.valueOf(productToAdd.ID), productToAdd.Name, String.valueOf(productToAdd.SellPrice), String.valueOf(productToAdd.BuyPrice), String.valueOf(productToAdd.Quantity),expDate, productToAdd.Category);
                                initialize();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("PRODUCTS GIVEN", ProductsStock));
                                }
                            } else if (Instruction.equals("DELETE PRODUCT")) {
                                Product productToDelete = (Product) DataReceived.object;
                                Remove("medications", String.valueOf(productToDelete.ID));
                                initialize();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("PRODUCTS GIVEN", ProductsStock));
                                }
                            } else if (Instruction.equals("EXIT")) {
                                String clientExited = (String) DataReceived.object;
                                System.out.println(clientExited + " WANTS TO EXIT");
                                for (int i = 0; i < Clients.size(); i++) {
                                    if (Clients.get(i).Name.equals(clientExited)) {
                                        Clients.remove(i);
                                    }
                                }
                                break;
                            } else if (Instruction.equals("ADD ORDER")) {
                                Order orderToAdd = (Order) DataReceived.object;
                                AddPatient(String.valueOf(orderToAdd.Patient.ID), orderToAdd.Patient.FirstName, orderToAdd.Patient.LastName, orderToAdd.Patient.PhoneNumber, orderToAdd.Patient.Adress, orderToAdd.Patient.Note, String.valueOf(orderToAdd.Patient.Age), orderToAdd.Patient.Gender);
                                AddLog(String.valueOf(orderToAdd.ID), String.valueOf(orderToAdd.Patient.ID), String.valueOf(orderToAdd.ID), String.valueOf(orderToAdd.getTotal()), Timestamp.valueOf(orderToAdd.Date));
                                for (ProductOnCart prod : orderToAdd.Purchases) {
                                    AddPurchase(String.valueOf(orderToAdd.ID), String.valueOf(prod.Product.ID), String.valueOf(prod.Quantity));
                                }
                                System.out.println("ORDER ADDED");
                            } else if (Instruction.equals("FETCH ORDERS")) {
                                initializeOrders();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("ORDERS GIVEN", OrdersList));
                                }
                            } else if (Instruction.equals("FETCH PATIENTS")) {
                                initializePatients();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("PATIENTS GIVEN", PatientsList));
                                }
                            } else if (Instruction.equals("UPDATE PRODUCT")) {
                                Product prodToUpdate = (Product) DataReceived.object;
                                UpdateProduct(prodToUpdate);
                                System.out.println("UPDATED " + prodToUpdate.Name);
                                initialize();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("PRODUCTS GIVEN", ProductsStock));
                                }
                            } else if (Instruction.equals("UPDATE ORDER")) {
                                Patient newPatient = (Patient) DataReceived.object;
                                System.out.println("PATIENT ID "+newPatient.ID);
                                UpdatePatient2(newPatient);
                                initializePatients();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("ORDER UPDATED", PatientsList));
                                }
                            } else if (Instruction.equals("DELETE ORDER")) {
                                Order orderToDelete = (Order) DataReceived.object;
                                Remove("log", String.valueOf(orderToDelete.ID));
                                RemovePurchases(String.valueOf(orderToDelete.ID));
                                initializeOrders();
                                for (ClientHandler client : Clients) {
                                    client.objectOutputStream.writeObject(new Data("ORDERS GIVEN", OrdersList));
                                }
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    System.out.println("CLOSING");
                    try {
                        socket.close();
                    } catch (IOException ex) {
                        Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            receiveMsg.start();
        }
    }

    public static void RemovePurchases(String Order_ID) {
        String query = "DELETE FROM purchases WHERE code= '" + Order_ID + "'";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "ronahaytem78");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void initializePatients() {
        ArrayList<Patient> patientArray = new ArrayList();
        String query = "SELECT * FROM patients";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                patientArray.add(new Patient(rs.getInt("code"), rs.getString("first_name"), rs.getString("last_name"), rs.getString("phone_number"), rs.getString("adresse"), rs.getString("note"),Integer.parseInt(rs.getString("age").trim()), rs.getString("gender")));
            }
            PatientsList = patientArray;
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void UpdatePatient2(Patient p) {
        String query = "UPDATE patients SET "
                + "code = " + "'" + p.ID + "',first_name = '" + p.FirstName + "',last_name = '" + p.LastName + "',age ="
                + " " + p.Age + ",phone_number = " + p.PhoneNumber + ",adresse = '" + p.Adress + "',note = '" + p.Note + "' "
                + "WHERE code = " + p.ID + "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void UpdateProduct(Product p) {
        String query = "UPDATE medications SET "
                + "code = '" + p.ID + "',name = '" + p.Name + "',sell_price = " + p.SellPrice + ","
                + "buy_price = " + p.BuyPrice + ",quantity = " + p.Quantity + ",exp_date = '" + p.ExpDate + "',"
                + "category = '" + p.Category + "' WHERE code = " + p.ID;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPatient(String ID,String FirstName,String LastName,String PhoneNumber,String Adress,String Note,String Age,String Gender) {
        String query = "INSERT INTO patients VALUES ('"+ID+"','"+FirstName+"','"+LastName+"','"+PhoneNumber+"','"+Adress+"','"+Note+"','"+Age+"','"+Gender+"' )";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddPurchase(String code, String product, String quantity) {
        String query = "INSERT INTO purchases VALUES ('" + code + "','" + product + "'," + quantity + ")";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddLog(String code, String client, String purchase_ID, String total_price, Timestamp date) {
        String query = "INSERT INTO log VALUES ('" + code + "','" + client + "'," + purchase_ID + "," + total_price + ", TIMESTAMP '" + date + "')";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void initializeOrders() {
        ArrayList<Order> tempOrders = new ArrayList();
        String query = "SELECT * FROM log";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            Statement st1 = connection.createStatement();
            Statement st2 = connection.createStatement();
            Statement st3 = connection.createStatement();
            Statement st4 = connection.createStatement();
            ResultSet rs = st1.executeQuery(query);
            while (rs.next()) {
                ResultSet prs = st2.executeQuery("SELECT * FROM patients WHERE code = " + rs.getInt("client") + ";");
                prs.next();
                Patient p = new Patient(prs.getInt("code"), prs.getString("first_name"), prs.getString("last_name"), prs.getString("phone_number"), prs.getString("adresse"), prs.getString("note"),Integer.parseInt(prs.getString("age").trim()), prs.getString("gender"));
                prs.close();
                ResultSet mrs = st3.executeQuery("SELECT * FROM purchases WHERE code = " + rs.getInt("purchase_ID") + ";");
                ArrayList<ProductOnCart> cartArray = new ArrayList<ProductOnCart>();
                while (mrs.next()) {
                    ResultSet srs = st4.executeQuery("SELECT * FROM medications WHERE code = " + mrs.getInt("product") + ";");
                    srs.next();
                    Product m = new Product(srs.getInt("code"), srs.getString("name"), srs.getString("category"), "someone", srs.getInt("sell_price"), srs.getInt("buy_price"), srs.getInt("quantity"), srs.getString("exp_date"));
                    srs.close();
                    ProductOnCart poc = new ProductOnCart(m, mrs.getInt("quantity"));
                    cartArray.add(poc);
                }
                tempOrders.add(new Order(rs.getInt("code"), p, cartArray, LocalDateTime.now()));
            }
            OrdersList = tempOrders;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void Remove(String table, String PrimaryKey) {
        String query = "DELETE FROM " + table + " WHERE code= '" + PrimaryKey + "'";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AddMedication(String code, String name, String sell_price, String buy_price, String quantity, Timestamp exp_date, String category) {
        String query = "INSERT INTO medications VALUES ('" + code + "','" + name + "'," + sell_price + "," + buy_price + "," + quantity + ", TIMESTAMP '" + exp_date + "','" + category + "')";
        try {
            System.out.println(query);
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            PreparedStatement pst = connection.prepareStatement(query);
            pst.execute(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void initialize() {
        String query = "SELECT * FROM medications";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/phar_database";
            Connection connection = DriverManager.getConnection(url, "root", "Mohmed.4717");
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
            ArrayList<Product> ProductsStockTemp = new ArrayList();
            while (rs.next()) {
                ProductsStockTemp.add(new Product(rs.getInt("code"), rs.getString("name"), rs.getString("category"), "someone", rs.getInt("sell_price"), rs.getInt("buy_price"), rs.getInt("quantity"), rs.getString("exp_date")));
            }
            ProductsStock = ProductsStockTemp;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
