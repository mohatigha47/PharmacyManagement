/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo1;

import java.io.Serializable;

/**
 *
 * @author moh
 */
public class ProductOnCart implements Serializable{
    Product Product;
    int Quantity;
    public ProductOnCart(Product Product,int Quantity){
        this.Product = Product;
        this.Quantity = Quantity;
    }
    double getPrice(){
        return Product.SellPrice*Quantity;
    }
}
